package br.edu.ifsp.arq.tsi.inoo.employees.view;

import br.edu.ifsp.arq.tsi.inoo.employees.controller.EmployeesController;
import br.edu.ifsp.arq.tsi.inoo.employees.model.ComissionedEmployee;
import br.edu.ifsp.arq.tsi.inoo.employees.model.Employee;
import br.edu.ifsp.arq.tsi.inoo.employees.model.HourlyEmployee;
import br.edu.ifsp.arq.tsi.inoo.employees.model.SalariedAndComissionedEmployee;
import br.edu.ifsp.arq.tsi.inoo.employees.model.SalariedEmployee;

public class App {
    public static void main(String[] args) throws Exception {
        EmployeesController controller = EmployeesController.getInstance();

        SalariedEmployee e1 = new SalariedEmployee("Ana Maria", "123.456.789-00", 3000.00);
        System.out.println(e1);
        // genérico
        System.out.println(e1.getName());
        // específico
        if(e1 instanceof SalariedEmployee){
            SalariedEmployee s = (SalariedEmployee)e1;
            System.out.println(s.getSalary());
        }
        Employee e2 = new HourlyEmployee("Eliana", "111.222.333-44", 160, 30);
        System.out.println(e2);
        Employee e3 = new ComissionedEmployee("Juliana", "999.888.777-66", 100000.00, 5);
        System.out.println(e3);
        Employee e4 = new SalariedAndComissionedEmployee("Adriana", "987.654.321-00", 50000.00, 3, 2000.00);
        System.out.println(e4);
        // adicionar no controlador
        controller.save(e1);
        controller.save(e2);
        controller.save(e3);
        controller.save(e4);
        System.out.println(controller.getEmployees());
    }
}
