public class App {
    public static void main(String[] args) throws Exception {
        GameWindow gameWindow = new GameWindow();
    }
}
