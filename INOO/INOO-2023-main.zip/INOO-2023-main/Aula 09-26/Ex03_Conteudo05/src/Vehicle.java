public class Vehicle {
    
    // atributos
    private String plate;
    private int entryHour;
    private int entryMinutes;
    private int exitHour;
    private int exitMinutes;

    private Vehicle(String plate, int entryHour, int entryMinutes, int exitHour, int exitMinutes) {
        this.plate = plate;
        this.entryHour = entryHour;
        this.entryMinutes = entryMinutes;
        this.exitHour = exitHour;
        this.exitMinutes = exitMinutes;
    }

    public static Vehicle getInstance(String plate, int entryHour, int entryMinutes, int exitHour, int exitMinutes){
        if(isValid(plate, entryHour, entryMinutes, exitHour, exitMinutes)){
            return new Vehicle(plate, entryHour, entryMinutes, exitHour, exitMinutes);
        }
        return null;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        if(isValidPlate(plate)){
            this.plate = plate;
        }
    }

    public int getEntryHour() {
        return entryHour;
    }

    public void setEntryHour(int entryHour) {
        if(isValidTime(entryHour, this.entryMinutes, this.exitHour, this.exitMinutes)){
            this.entryHour = entryHour;
        }
    }

    public int getEntryMinutes() {
        return entryMinutes;
    }

    public void setEntryMinutes(int entryMinutes) {
        if(isValidTime(this.entryHour, entryMinutes, this.exitHour, this.exitMinutes))
        this.entryMinutes = entryMinutes;
    }

    public int getExitHour() {
        return exitHour;
    }

    public void setExitHour(int exitHour) {
        if(isValidTime(this.entryHour, this.entryMinutes, exitHour, this.exitMinutes))
        this.exitHour = exitHour;
    }

    public int getExitMinutes() {
        return exitMinutes;
    }

    public void setExitMinutes(int exitMinutes) {
        if(isValidTime(this.entryHour, this.entryMinutes, this.exitHour, exitMinutes))
        this.exitMinutes = exitMinutes;
    }

    public static boolean isValid(String plate, int entryHour, int entryMinutes, int exitHour, int exitMinutes){
        return isValidPlate(plate) && isValidTime(entryHour, entryMinutes, exitHour, exitMinutes);
    }

    public static boolean isValidPlate(String plate){
        if(plate != null){
            return !plate.isBlank();
        }
        return false;
        //return !plate.trim().isEmpty();
    }

    public static boolean isValidTime(int entryHour, int entryMinutes, int exitHour, int exitMinutes){
        return isValidHour(entryHour) && isValidHour(exitHour) && isValidMinutes(entryMinutes) && isValidMinutes(exitMinutes) &&
        ((entryHour < exitHour) || (entryHour  == exitHour && entryMinutes < exitMinutes));
    }

    public static boolean isValidHour(int hour){
        return hour >= 8 && hour < 23;
    }

    public static boolean isValidMinutes(int minutes){
        return minutes >= 0 && minutes < 60;
    }

    public double calculateParkingFee(){
        double parkingFee;
        int time = calculateParkingTime();
        if(time <= 1){
            parkingFee = 6.0;
        }else{
            parkingFee = 6.0 + ((time -1) * 1.0);
        }
        return parkingFee;
    }

    public int calculateParkingTime(){
        return ((exitHour * 60 + exitMinutes) - (entryHour * 60 + entryMinutes)) / 60;
    }

    public double calculateDiscountedParkingFee(){
        double parkingFee = calculateParkingFee();
        if(parkingFee <= 10.0){
            return parkingFee - (parkingFee * 0.05);
        }else if(parkingFee <= 15.0){
            return parkingFee - (parkingFee * 0.10);
        }else{
            return parkingFee - (parkingFee * 0.15);
        }
    }

    @Override
    public String toString() {
        return "Vehicle [plate=" + plate + ", entryHour=" + entryHour + ", entryMinutes=" + entryMinutes + ", exitHour="
                + exitHour + ", exitMinutes=" + exitMinutes + "]";
    }


}
