public class App {
    public static void main(String[] args) throws Exception {
        Vehicle vehicle = Vehicle.getInstance("AAA1111", 8, 0, 22, 59);
        System.out.println(vehicle);
        if(vehicle != null){
            System.out.printf("Valor da taxa completa: R$ %.2f\n", vehicle.calculateParkingFee());
            System.out.printf("Valor da taxa com desconto: R$ %.2f\n", vehicle.calculateDiscountedParkingFee());
        }
    }
}
