package br.edu.ifsp.arq.tsi.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.model.Person;

public class PersonsController {
    
    private static PersonsController instance;

    private ArrayList<Person> persons;

    private PersonsController(){
        persons = new ArrayList<>();
    }

    public static synchronized PersonsController getInstance() {
        if(instance == null){
            instance = new PersonsController();
        }
        return instance;
    }

    public boolean save(Person person){
        if(person != null){
            return persons.add(person);
        }
        return false;
    }

    public Person findByName(String name){
        for(Person p: persons){
            if(p.getName().equalsIgnoreCase(name)){
                return p;
            }
        }
        return null;
    }

    public Person findByCpf(String cpf){
        for(Person p: persons){
            if(p.getCpf().equalsIgnoreCase(cpf)){
                return p;
            }
        }
        return null;
    }

    public boolean update(Person person){
        int index = persons.indexOf(person);
        if(index != -1){
            persons.set(index, person);
            return true;
        }
        return false;
    }

    public boolean remove(Person person){
        return persons.remove(person);
    }

    public ArrayList<Person> getPersons() {
        return persons;
    }
    
}
