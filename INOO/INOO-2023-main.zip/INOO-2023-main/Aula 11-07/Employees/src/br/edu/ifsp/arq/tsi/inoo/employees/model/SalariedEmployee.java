package br.edu.ifsp.arq.tsi.inoo.employees.model;

public class SalariedEmployee extends Employee {

    private double salary;

    public SalariedEmployee(String name, String cpf, double salary) {
        super(name, cpf);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public double calculateIncome(){
        return salary;
    }

    @Override
    public String toString() {
        return super.toString() + 
        " Salário fixo: R$ " + String.format("%.2f", salary);
    }

    
}
