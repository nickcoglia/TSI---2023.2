package br.edu.ifsp.arq.tsi.inoo.employees.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.inoo.employees.model.Employee;

public class EmployeesController {
    
    private static EmployeesController instance;

    private ArrayList<Employee> employees;

    private EmployeesController(){
        employees = new ArrayList<>();
    }

    public static EmployeesController getInstance(){
        if(instance == null){
            instance = new EmployeesController();
        }
        return instance;
    }

    public boolean save(Employee employee){
        if(employee != null){
            return employees.add(employee);
        }
        return false;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public String generateReport(){
        StringBuilder report = new StringBuilder();
        for(Employee e : employees){
            report.append("Nome: " + e.getName() +
            " - Rendimentos: R$ " + String.format("%.2f", e.calculateIncome()));
            report.append("\n*****************************************\n");
        }
        return report.toString();
    }
}
