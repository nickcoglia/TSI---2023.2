package br.edu.ifsp.arq.tsi.inoo.employees.model;

public class SalariedAndComissionedEmployee extends ComissionedEmployee {

    private double salary;

    public SalariedAndComissionedEmployee(String name, String cpf, double salesValue, double comissionPercentage,
            double salary) {
        super(name, cpf, salesValue, comissionPercentage);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public double calculateIncome() {
        return super.calculateIncome() + salary;
    }

    @Override
    public String toString() {
        return super.toString() + 
        " Salário fixo: R$ " + String.format("%.2f", salary);
    }

    
}
