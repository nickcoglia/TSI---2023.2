package br.edu.ifsp.arq.tsi.inoo.employees.model;

public class HourlyEmployee extends Employee {

    private int numberOfHoursWorked;
    private double valueOfWorkedHour;

    public HourlyEmployee(String name, String cpf, int numberOfHoursWorked, double valueOfWorkedHour) {
        super(name, cpf);
        this.numberOfHoursWorked = numberOfHoursWorked;
        this.valueOfWorkedHour = valueOfWorkedHour;
    }

    public int getNumberOfHoursWorked() {
        return numberOfHoursWorked;
    }

    public void setNumberOfHoursWorked(int numberOfHoursWorked) {
        this.numberOfHoursWorked = numberOfHoursWorked;
    }

    public double getValueOfWorkedHour() {
        return valueOfWorkedHour;
    }

    public void setValueOfWorkedHour(double valueOfWorkedHour) {
        this.valueOfWorkedHour = valueOfWorkedHour;
    }

    @Override
    public double calculateIncome() {
        return numberOfHoursWorked * valueOfWorkedHour;
    }

    @Override
    public String toString() {
        return super.toString() +
        " Valor da hora trabalhada: R$ " + String.format("%.2f", valueOfWorkedHour) + 
        " Número de horas trabalhadas: " + numberOfHoursWorked + "hora(s)";
    }
   
}
