public class App {
    public static void main(String[] args) throws Exception {
        Smartphone s1 = new Smartphone(1000.00, false, false, false, false);
        System.out.println(s1);
        System.out.println("******************************************************");
        Smartphone s2 = new Smartphone(1000.00, true, false, false, false);
        System.out.println(s2);
        System.out.println("******************************************************");
        Smartphone s3 = new Smartphone(1000.00, true, true, false, false);
        System.out.println(s3);
        System.out.println("******************************************************");
        Smartphone s4 = new Smartphone(1000.00, true, true, true, false);
        System.out.println(s4);
        System.out.println("******************************************************");
        Smartphone s5 = new Smartphone(1000.00, false, true, true, true);
        System.out.println(s5);
        System.out.println("******************************************************");
        Smartphone s6 = new Smartphone(1000.00, true, true, true, true);
        System.out.println(s6);
        System.out.println("******************************************************");
    }
}
