public class Smartphone {

  private double basicPrice;
  private boolean planType; // false = pré-pago; true = pós-pago
  private boolean extraBattery;
  private boolean cover;
  private boolean headset;

  public Smartphone(double basicPrice, boolean planType, boolean extraBattery, boolean cover, boolean headset) {
    this.basicPrice = basicPrice;
    this.planType = planType;
    this.extraBattery = extraBattery;
    this.cover = cover;
    this.headset = headset;
  }

  public double getBasicPrice() {
    return basicPrice;
  }

  public void setBasicPrice(double basicPrice) {
    this.basicPrice = basicPrice;
  }

  public boolean isPlanType() {
    return planType;
  }

  public void setPlanType(boolean planType) {
    this.planType = planType;
  }

  public boolean isExtraBattery() {
    return extraBattery;
  }

  public void setExtraBattery(boolean extraBattery) {
    this.extraBattery = extraBattery;
  }

  public boolean isCover() {
    return cover;
  }

  public void setCover(boolean cover) {
    this.cover = cover;
  }

  public boolean isHeadset() {
    return headset;
  }

  public void setHeadset(boolean headset) {
    this.headset = headset;
  }

  public double calculateFinalPrice(){
    double finalPrice = basicPrice;
    if(planType){
      finalPrice *= 0.95;
    }
    if(extraBattery){
      finalPrice += 250;
    }
    if(cover){
      finalPrice += 50;
    }
    if(headset){
      finalPrice += 45;
    }
    return finalPrice;
  }

  @Override
  public String toString() {
    String msg = "";
        msg += "Preço básico: R$ " + String.format("%.2f", basicPrice) + 
                "\nTipo de plano: ";
        msg += planType ? "pós-pago" : "pré-pago";
        msg += extraBattery ? "\nCom bateria extra" : "";
        msg += cover ? "\nCom capa" :"";
        msg += headset ? "\nCom fone de ouvido" : "";
        msg += "\n\nPreço final: R$ " + String.format("%.2f", calculateFinalPrice());
        return msg;
  }

}
