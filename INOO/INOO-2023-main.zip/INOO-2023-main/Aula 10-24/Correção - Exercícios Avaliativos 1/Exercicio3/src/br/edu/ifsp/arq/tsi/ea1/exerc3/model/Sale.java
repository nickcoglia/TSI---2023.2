package br.edu.ifsp.arq.tsi.ea1.exerc3.model;

public class Sale {

  private int code;
  private String fanName;
  private boolean commonFan;
  private int type; // 1 - setor amarelo, 2 - setor azul, 3 - setor branco e 4 - setor verde
  private int ticketQuantity;
  private String date;
  private String time;

  public Sale(int code, String fanName, boolean commonFan, int type, int ticketQuantity, String date, String time) {
    this.code = code;
    this.fanName = fanName;
    this.commonFan = commonFan;
    this.type = type;
    this.ticketQuantity = ticketQuantity;
    this.date = date;
    this.time = time;
  }

  public Sale(String fanName, boolean commonFan, int type, int ticketQuantity, String date, String time) {
    this.fanName = fanName;
    this.commonFan = commonFan;
    this.type = type;
    this.ticketQuantity = ticketQuantity;
    this.date = date;
    this.time = time;
  }

  public int getCode() {
    return code;
  }

  public void setCode(int code) {
    this.code = code;
  }

  public String getFanName() {
    return fanName;
  }

  public void setFanName(String fanName) {
    this.fanName = fanName;
  }

  public boolean isCommonFan() {
    return commonFan;
  }

  public void setCommonFan(boolean commonFan) {
    this.commonFan = commonFan;
  }

  public int getType() {
    return type;
  }

  public void setType(int type) {
    this.type = type;
  }

  public int getTicketQuantity() {
    return ticketQuantity;
  }

  public void setTicketQuantity(int ticketQuantity) {
    this.ticketQuantity = ticketQuantity;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  @Override
  public String toString() {
    return "Sale [code=" + code + ", fanName=" + fanName + ", commonFan=" + commonFan + ", type=" + type
        + ", ticketQuantity=" + ticketQuantity + ", date=" + date + ", time=" + time + "]";
  }

}
