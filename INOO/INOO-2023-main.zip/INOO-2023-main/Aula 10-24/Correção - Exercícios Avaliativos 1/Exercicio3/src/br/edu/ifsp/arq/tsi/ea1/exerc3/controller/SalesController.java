package br.edu.ifsp.arq.tsi.ea1.exerc3.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.ea1.exerc3.model.Sale;

public class SalesController {

  private static SalesController instance;

  private ArrayList<Sale> sales;
  private int nextCode;

  private int yellowQuantity;
  private int blueQuantity;
  private int whiteQuantity;
  private int greenQuantity;

  public static final int YELLOW = 1;
  public static final int BLUE = 2;
  public static final int WHITE = 3;
  public static final int GREEN = 4;

  private final double YELLOW_VALUE = 180.00;
  private final double BLUE_VALUE = 120.00;
  private final double WHITE_VALUE = 80.00;
  private final double GREEN_VALUE = 350.00;

  private SalesController() {
    sales = new ArrayList<>();
    yellowQuantity = 4; // 20
    blueQuantity = 6; // 30
    whiteQuantity = 8; // 40
    greenQuantity = 10;
  }

  public static synchronized SalesController getInstance() {
    if (instance == null) {
      return new SalesController();
    }
    return instance;
  }

  public boolean save(Sale sale){
    if(sale != null && hasTickets(sale.getType(), sale.getTicketQuantity())){
      sale.setCode(++nextCode);
      sales.add(sale);
      updateQuantity(sale.getType(), sale.getTicketQuantity());
      return true;
    }
    return false;
  }

  private boolean hasTickets(int type, int ticketQuantity) {
    switch(type){
      case YELLOW:
        return yellowQuantity >= ticketQuantity;
      case BLUE:
        return blueQuantity >= ticketQuantity;
      case WHITE:
        return whiteQuantity >= ticketQuantity;
      case GREEN:
        return greenQuantity >= ticketQuantity;
      default:
        return false;
    }
  }
  
  private void updateQuantity(int type, int ticketQuantity) {
    switch(type){
      case YELLOW:
        yellowQuantity -= ticketQuantity;
        break;
      case BLUE:
        blueQuantity -= ticketQuantity;
        break;
      case WHITE:
        whiteQuantity -= ticketQuantity;
        break;
      case GREEN:
        greenQuantity -= ticketQuantity;
        break;
    }
  }

  public double calculateTotalAmount(Sale sale) {
    double totalAmount = 0;
    switch (sale.getType()) {
      case YELLOW:
        totalAmount = YELLOW_VALUE * sale.getTicketQuantity();
        break;
      case BLUE:
        totalAmount = BLUE_VALUE * sale.getTicketQuantity();
        break;
      case WHITE:
        totalAmount = WHITE_VALUE * sale.getTicketQuantity();
        break;
      case GREEN:
        totalAmount = GREEN_VALUE * sale.getTicketQuantity();
        break;
    }
    if (!sale.isCommonFan()) {
      totalAmount *= 0.5;
    }
    return totalAmount;
  }

  public String generateReport(){
    String msg = "RELATÓRIO DE VENDAS\n";
    msg += "---------------------------------------------------\n";
    for(Sale s : sales){
      msg += "Venda: " + s.getCode() + "\n";
      msg += "Nome do torcedor: " + s.getFanName() + "\n";
      msg += "Tipo de torcedor: " + (s.isCommonFan() ? "Comum" : "Aposentado ou Estudante") + "\n";
      msg += "Tipo do ingresso: " + toTypeName(s.getType()) + "\n";
      msg += "Quantidade de ingressos: " + s.getTicketQuantity() + "\n";
      msg += "Valor unitário (entrada normal): R$ " + String.format("%.2f", getValue(s.getType())) + "\n";
      msg += "Valor total: R$ " + String.format("%.2f", calculateTotalAmount(s)) + "\n";
      msg += "Data: " + s.getDate() + "\n";
      msg += "Hora: " + s.getTime() + "\n";
      msg += "---------------------------------------------------\n";
    }
    return msg;
  }

  private String toTypeName(int type){
    switch(type){
      case YELLOW:
        return "Setor Amarelo";
      case BLUE:
        return "Setor Azul";
      case WHITE:
        return "Setor Branco";
      case GREEN:
        return "Setor Verde";
      default:
        return "";
    }
  }

  private double getValue(int type){
    switch(type){
      case YELLOW:
        return YELLOW_VALUE;
      case BLUE:
        return BLUE_VALUE;
      case WHITE:
        return WHITE_VALUE;
      case GREEN:
        return GREEN_VALUE;
      default:
        return 0.0;
    }
  }

}
