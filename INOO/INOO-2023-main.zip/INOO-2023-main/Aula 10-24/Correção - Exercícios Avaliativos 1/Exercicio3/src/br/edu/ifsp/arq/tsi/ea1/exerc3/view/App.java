package br.edu.ifsp.arq.tsi.ea1.exerc3.view;

import br.edu.ifsp.arq.tsi.ea1.exerc3.controller.SalesController;
import br.edu.ifsp.arq.tsi.ea1.exerc3.model.Sale;

public class App {
  public static void main(String[] args) throws Exception {
    SalesController controller = SalesController.getInstance();
    Sale s1 = new Sale("Torcedor 1", true, SalesController.YELLOW, 3, "23/10/2023","08:00");
    if(controller.save(s1)){
      System.out.println("Venda realizada com sucesso:");
      System.out.println(s1);
    }else{
      System.out.println("Venda NÃO realizada.");
    }
    Sale s2 = new Sale("Torcedor 2", false, SalesController.GREEN, 4, "23/10/2023","08:05");
    if(controller.save(s2)){
      System.out.println("Venda realizada com sucesso:");
      System.out.println(s2);
    }else{
      System.out.println("Venda NÃO realizada.");
    }
    Sale s3 = new Sale("Torcedor 3", true, SalesController.YELLOW, 4, "23/10/2023","08:10");
    if(controller.save(s3)){
      System.out.println("Venda realizada com sucesso:");
      System.out.println(s3);
    }else{
      System.out.println("Venda NÃO realizada.");
    }
    // relatório
    System.out.println(controller.generateReport());
  }
}
