package br.edu.ifsp.arq.tsi.inoo.model;
public class Product {

    private Long id;
    private String description;
    private Double price;
    private Integer quantityInStock;

    public Product(Long id, String description, Double price, Integer quantityInStock) {
        this.id = id;
        this.description = description;
        this.price = price;
        this.quantityInStock = quantityInStock;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(Integer quantityInStock) {
        this.quantityInStock = quantityInStock;
    }

    @Override
    public String toString() {
        return "Código: " + id + " - Descrição: " + description + 
            " - Valor: R$ " + String.format("%.2f", price) +
            " - Quantidade em estoque: " + quantityInStock;
    }
}
