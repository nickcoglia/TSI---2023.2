package br.edu.ifsp.arq.tsi.inoo.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.inoo.model.Client;

public class ClientsController {
  
  private static ClientsController instance;

  private ArrayList<Client> clients;

  private ClientsController(){
    clients = new ArrayList<>();
  }

  public static synchronized ClientsController getInstance(){
    if(instance == null){
      return new ClientsController();
    }
    return instance;
  }

  public boolean save(Client client) {
    if (client != null) {
      return clients.add(client);
    }
    return false;
  }

  public Client findById(int id) {
    for (Client c : clients) {
      if (c.getId() == id) {
        return c;
      }
    }
    return null;
  }
  
}
