package br.edu.ifsp.arq.tsi.inoo.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.inoo.model.Product;

public class ProductsController {
  
  private static ProductsController instance;

  private ArrayList<Product> products;

  private ProductsController(){
    products = new ArrayList<>();
  }

  public static synchronized ProductsController getInstance(){
    if(instance == null){
      return new ProductsController();
    }
    return instance;
  }

  public boolean save(Product product) {
    if (product != null) {
      return products.add(product);
    }
    return false;
  }

  public Product findById(int id) {
    for (Product p : products) {
      if (p.getId() == id) {
        return p;
      }
    }
    return null;
  }
}
