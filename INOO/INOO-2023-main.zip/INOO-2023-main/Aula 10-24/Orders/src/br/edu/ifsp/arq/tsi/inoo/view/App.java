package br.edu.ifsp.arq.tsi.inoo.view;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.inoo.controller.ClientsController;
import br.edu.ifsp.arq.tsi.inoo.controller.OrdersController;
import br.edu.ifsp.arq.tsi.inoo.controller.ProductsController;
import br.edu.ifsp.arq.tsi.inoo.model.Client;
import br.edu.ifsp.arq.tsi.inoo.model.Order;
import br.edu.ifsp.arq.tsi.inoo.model.OrderItem;
import br.edu.ifsp.arq.tsi.inoo.model.Product;

public class App {
  public static void main(String[] args) throws Exception {
    // cadastrar clientes
    ClientsController clientsController = ClientsController.getInstance();
    Client c1 = new Client(1L, "Ana Maria",
        "123.456.789-00", "Rua Sem Nome, Sem Número");
    clientsController.save(c1);

    // cadastrar produtos
    ProductsController productsController = ProductsController.getInstance();
    Product p1 = new Product(1L,
        "Coxinha de brócolis com catury", 4.5,
        10);
    productsController.save(p1);
    Product p2 = new Product(2L, "Suco de laranja",
        5.0, 5);
    productsController.save(p2);

    // cadastrar pedido
    OrdersController ordersController = OrdersController.getInstance();
    Order o1 = new Order(1L, clientsController.findById(1), null, 0.0);
    ordersController.save(o1);
    // cadastrar itens do pedido
    ArrayList<OrderItem> itens = new ArrayList<>();
    OrderItem i1 = new OrderItem();
    if (i1.addProduct(p1, 2)) {
      System.out.println("Produto adicionado com sucesso!");
      itens.add(i1);
    } else {
      System.out.println("ERRO: estoque insuficiente do produto" +
          " ou quantidade inválida");
    }
    OrderItem i2 = new OrderItem();
    if (i2.addProduct(p2, 2)) {
      System.out.println("Produto adicionado com sucesso!");
      itens.add(i2);
    } else {
      System.out.println("ERRO: estoque insuficiente do produto" +
          " ou quantidade inválida");
    }
    // guardar os itens no pedio
    ordersController.findByNumber(1).setOrderItens(itens);
    // imprimir o pedido
    System.out.println("**************************");
    System.out.println("Dados do Pedido:");
    System.out.println(ordersController.findByNumber(1));
  }
}
