package br.edu.ifsp.arq.tsi.inoo.model;
public class OrderItem {
    
    private Order order; // composição objeto-parte
    private Product product; // associação
    private Integer quantity;

    // construtor padrão
    public OrderItem() {
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Product getProduct() {
        return product;
    }

    public boolean addProduct(Product product, Integer quantity) {
        setQuantity(quantity);
        if(product.getQuantityInStock() >= this.quantity){
            this.product = product;
            this.product.setQuantityInStock(product.getQuantityInStock() -
                quantity);
            return true;
        }
        return false;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        if(quantity > 0){
            this.quantity = quantity;
        }else{
            this.quantity = 1; // valor default
        }
        
    }

    @Override
    public String toString() {
        return "Produto: {" + product + "}\n - Quantidade comprada: " + quantity
            + "\n";
    }

}
