package br.edu.ifsp.arq.tsi.inoo.model;
import java.time.LocalDate;
import java.util.ArrayList;

public class Order {
    
    private Long number;
    private LocalDate date;
    private Client client; // associação
    private ArrayList<OrderItem> orderItens; // composição objeto-todo
    private Double totalAmount;

    public Order(Long number, Client client, ArrayList<OrderItem> orderItens, Double totalAmount) {
        this.number = number;
        this.date = LocalDate.now();
        this.client = client;
        this.orderItens = orderItens;
        this.totalAmount = totalAmount;
    }

    public Long getNumber() {
        return number;
    }
    public void setNumber(Long number) {
        this.number = number;
    }
    public LocalDate getDate() {
        return date;
    }
    public void setDate(LocalDate date) {
        this.date = date;
    }
    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }
    public ArrayList<OrderItem> getOrderItens() {
        return orderItens;
    }
    public void setOrderItens(ArrayList<OrderItem> orderItens) {
        this.orderItens = orderItens;
    }
    public Double getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double calculateTotalAmount(){
      double total = 0;
      for(OrderItem item: orderItens){
        total += item.getProduct().getPrice() * item.getQuantity();
      }
      setTotalAmount(total);
      return total;
    }

    @Override
    public String toString() {
        StringBuilder order = new StringBuilder();

        order.append("Número do pedido: " + number + "\n");
        order.append("Data de emissão: " + date + "\n");
        order.append("Cliente: {" + client + "}\n");
        // dados dos itens
        for(OrderItem item : orderItens){
            order.append(item);
        }
        order.append(String.format("Valor total: R$ %.2f\n", calculateTotalAmount()));
        return order.toString(); 
    }
}
