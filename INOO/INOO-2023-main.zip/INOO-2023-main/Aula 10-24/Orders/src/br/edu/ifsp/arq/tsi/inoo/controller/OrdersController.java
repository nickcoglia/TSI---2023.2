package br.edu.ifsp.arq.tsi.inoo.controller;

import java.util.ArrayList;

import br.edu.ifsp.arq.tsi.inoo.model.Order;

public class OrdersController {
  
  private static OrdersController instance;

  private ArrayList<Order> orders;

  private OrdersController(){
    orders = new ArrayList<>();
  }

  public static synchronized OrdersController getInstance(){
    if(instance == null){
      return new OrdersController();
    }
    return instance;
  }

  public boolean save(Order order) {
    if (order != null) {
      return orders.add(order);
    }
    return false;
  }

  public Order findByNumber(int number) {
    for (Order o : orders) {
      if (o.getNumber() == number) {
        return o;
      }
    }
    return null;
  }
}
