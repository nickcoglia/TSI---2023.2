package br.edu.ifsp.arq.tsi.inoo.model;
public class Client {
    
    private Long id;
    private String name;
    private String cpf;
    private String address;

    public Client(Long id, String name, String cpf, String address){
        this.id = id;
        this.name = name;
        this.cpf = cpf;
        this.address = address;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCpf() {
        return cpf;
    }

    public String getAddress() {
        return address;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString(){
        return "Código: " + id + " - Nome: " + name + " - CPF: " + cpf +
            " - Endereço: " + address;
    }
}
