package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public class Compra implements Autorizavel, Imprimivel {

  private String nomeCliente;
  private double valorTotal;
  private String produto;
  private boolean internacional;

  public Compra(String nomeCliente, double valorTotal, String produto, boolean internacional) {
    this.nomeCliente = nomeCliente;
    this.valorTotal = valorTotal;
    this.produto = produto;
    this.internacional = internacional;
  }

  public String getNomeCliente() {
    return nomeCliente;
  }

  public void setNomeCliente(String nomeCliente) {
    this.nomeCliente = nomeCliente;
  }

  @Override
  public double getValorTotal() {
    return valorTotal;
  }

  public void setValorTotal(double valorTotal) {
    this.valorTotal = valorTotal;
  }

  public String getProduto() {
    return produto;
  }

  public void setProduto(String produto) {
    this.produto = produto;
  }

  public boolean isInternacional() {
    return internacional;
  }

  public void setInternacional(boolean internacional) {
    this.internacional = internacional;
  }

  @Override
  public String getCabecalhoPagina() {
    return nomeCliente;
  }

  @Override
  public String getCorpoPagina() {
    if(internacional){
      return produto + " = " + valorTotal + "\nIOF: " + Operadora.calcularIofTransacaoInternacional(this) ;
    }
    return produto + " = " + valorTotal;
  }


}
