package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public class Redecard implements Operadora {

  @Override
  public boolean autorizar(Autorizavel autorizavel, Cartao cartao) {
    return cartao.getNumeroCartao().startsWith("5678") && autorizavel.getValorTotal() < 1000;
  }
  
}
