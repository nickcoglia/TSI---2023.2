package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public class Cielo implements Operadora {

  public boolean autorizar(Autorizavel autorizavel, Cartao cartao) {
    return cartao.getNumeroCartao().startsWith("1234");
  }

}
