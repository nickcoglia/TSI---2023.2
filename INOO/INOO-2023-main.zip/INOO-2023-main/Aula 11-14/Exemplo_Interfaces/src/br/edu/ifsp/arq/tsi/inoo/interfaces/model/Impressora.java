package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public interface Impressora {

  default void imprimir(Imprimivel imprimivel) {
    System.out.println("*****************************");
    System.out.println(imprimivel.getCabecalhoPagina());
    System.out.println("*****************************");
    System.out.println(imprimivel.getCorpoPagina());
    System.out.println("-----------------------------");
  }

}
