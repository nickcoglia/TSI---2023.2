package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public class Checkout {

  private Operadora operadora;
  private Impressora impressora;

  public Checkout(Operadora operadora, Impressora impressora) {
    this.operadora = operadora;
    this.impressora = impressora;
  }

  public String fecharCompra(Compra compra, Cartao cartao) {
    if (operadora.autorizar(compra, cartao)) {
      impressora.imprimir(compra);
      return "Pagamento autorizado!";
    } else {
      return "Pagamento negado!";
    }
  }
}
