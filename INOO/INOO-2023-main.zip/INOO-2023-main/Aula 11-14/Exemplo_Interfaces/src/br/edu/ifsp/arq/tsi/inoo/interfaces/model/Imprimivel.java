package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public interface Imprimivel {

  String getCabecalhoPagina();

  String getCorpoPagina();
}
