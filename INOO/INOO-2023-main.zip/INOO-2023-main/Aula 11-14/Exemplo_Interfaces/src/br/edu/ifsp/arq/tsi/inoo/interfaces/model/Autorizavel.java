package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public interface Autorizavel {

  double getValorTotal();

}
