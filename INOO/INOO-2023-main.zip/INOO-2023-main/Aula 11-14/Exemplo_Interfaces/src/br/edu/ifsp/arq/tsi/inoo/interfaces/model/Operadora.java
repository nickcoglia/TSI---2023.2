package br.edu.ifsp.arq.tsi.inoo.interfaces.model;

public interface Operadora {

  boolean autorizar(Autorizavel autorizavel, Cartao cartao);

  // A partir do Java 8
  static double calcularIofTransacaoInternacional(Autorizavel autorizavel) {
    return autorizavel.getValorTotal() * 0.0638;
  }

}
