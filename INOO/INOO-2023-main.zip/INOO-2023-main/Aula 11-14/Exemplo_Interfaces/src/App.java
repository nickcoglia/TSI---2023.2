import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Cartao;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Checkout;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Cielo;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Compra;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Impressora;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.ImpressoraEpson;
import br.edu.ifsp.arq.tsi.inoo.interfaces.model.Operadora;

public class App {
  public static void main(String[] args) throws Exception {
    Operadora operadora = new Cielo();
    Impressora impressora = new ImpressoraEpson();
    Cartao cartao = new Cartao("JULIANA SILVA", "12345678");
    Compra compra = new Compra("Juliana da Silva", 8.0, "Sorvete", false);
    Checkout checkout = new Checkout(operadora, impressora);
    System.out.println(checkout.fecharCompra(compra, cartao));
    Compra compraInter = new Compra("Juliana da Silva", 1000.0, "Celular Xingling", true);
    System.out.println(checkout.fecharCompra(compraInter, cartao));
  }
}
