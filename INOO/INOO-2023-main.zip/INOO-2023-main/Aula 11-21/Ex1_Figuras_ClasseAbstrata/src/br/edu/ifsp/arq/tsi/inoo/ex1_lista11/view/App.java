package br.edu.ifsp.arq.tsi.inoo.ex1_lista11.view;

import br.edu.ifsp.arq.tsi.inoo.ex1_lista11.model.Triangle;

public class App {
    public static void main(String[] args) throws Exception {
        Triangle t1 = new Triangle(2, 2, 2);
        System.out.println("Área do triângulo: " + t1.calculateArea());
        System.out.println("Perímetro do triângulo: " + t1.calcultePerimeter());
    }
}
