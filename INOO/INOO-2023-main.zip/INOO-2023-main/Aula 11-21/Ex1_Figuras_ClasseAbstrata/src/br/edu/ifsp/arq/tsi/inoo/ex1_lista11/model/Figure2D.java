package br.edu.ifsp.arq.tsi.inoo.ex1_lista11.model;

public abstract class Figure2D extends Figure {
    
    public abstract double calcultePerimeter();

}
