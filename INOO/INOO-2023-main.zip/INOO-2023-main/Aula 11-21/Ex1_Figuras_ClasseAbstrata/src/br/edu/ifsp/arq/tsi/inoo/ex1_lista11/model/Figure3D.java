package br.edu.ifsp.arq.tsi.inoo.ex1_lista11.model;

public abstract class Figure3D {

    public abstract double calculateVolumn();
    
}
