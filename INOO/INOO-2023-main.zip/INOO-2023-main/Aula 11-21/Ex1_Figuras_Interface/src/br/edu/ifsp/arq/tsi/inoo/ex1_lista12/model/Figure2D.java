package br.edu.ifsp.arq.tsi.inoo.ex1_lista12.model;

public interface Figure2D extends Figure {
    
    double calculatePerimeter();
    
}
