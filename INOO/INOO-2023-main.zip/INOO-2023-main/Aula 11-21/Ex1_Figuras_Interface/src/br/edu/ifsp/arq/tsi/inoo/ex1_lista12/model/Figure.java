package br.edu.ifsp.arq.tsi.inoo.ex1_lista12.model;

public interface Figure {

    double calculateArea();
    
}