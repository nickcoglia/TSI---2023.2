public class App {
    public static void main(String[] args) throws Exception {
        // declaração de variáveis
        int number1, number2, sum;
        number1 = 10;
        number2 = 20;
        sum = number1 + number2;
        System.out.println("Soma = " + sum);
    }
}
