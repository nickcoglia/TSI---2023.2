public class Employee {
    
    // atributos
    private String name;
    private String surname;
    private double salary;

    // método construtor com argumentos
    public Employee(String name, String surname, double salary){
        setSurname(surname);
        setName(name);
        setSalary(salary);
    }

    public void setName(String name) {
        if(name != null && !name.equalsIgnoreCase(surname)){
            this.name = name;
        }else{
            this.name = ""; // valor default
        }
    }

    public void setSurname(String surname) {
        if(surname != null){
            this.surname = surname;
        }else{
            this.surname = ""; // valor default
        }
        
    }

    public void setSalary(double salary) {
        if(salary > 0){
            this.salary = salary;
        }else{
            this.salary = 0; // valor default
        }
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return String.format("Nome: %s - Sobrenome: %s - Salário: R$ %.2f\n", name, surname, salary);
    }

    public double calculateNewSalary(int years){
        double newSalary = salary;
        for(int i = 0; i < years; i++){
            newSalary += newSalary * 0.02;
        }
        return newSalary;
    }
}
