public class App {
    public static void main(String[] args) throws Exception {
        Employee employee = new Employee("duarte", "Duarte", 1000);
        System.out.println(employee);
        System.out.printf("Novo salário: R$ %.2f\n", employee.calculateNewSalary(3));
    }
}
