public class Book {

    private String title;
    private String author1;
    private String author2;
    private String publisher;
    private int yearOfPublication;
    private int pageNumber;

    public Book(String title, String author1, String publisher, int yearOfPublication) {
        this(title, author1, "", publisher, yearOfPublication, 0);
    }

    public Book(String title, String author1, String publisher, int yearOfPublication, int pageNumber) {
        this(title, author1, "", publisher, yearOfPublication, pageNumber);
    }

    public Book(String title, String author1, String author2, String publisher, int yearOfPublication) {
        this(title, author1, author2, publisher, yearOfPublication, 0);
    }

    public Book(String title, String author1, String author2, String publisher, int yearOfPublication, int pageNumber) {
        this.title = title;
        this.author1 = author1;
        this.author2 = author2;
        this.publisher = publisher;
        this.yearOfPublication = yearOfPublication;
        this.pageNumber = pageNumber;
    }

    @Override
    public String toString() {
        return "Livro [título=" + title + ", autor 1=" + author1 + ", autor 2=" + author2 + ", editora=" + publisher
                + ", ano de publicação=" + yearOfPublication + ", número de páginas=" + pageNumber + "]";
    }

    
}