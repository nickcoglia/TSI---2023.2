public class App {
    public static void main(String[] args) throws Exception {
        Book b1 = new Book("Java: Como programar", "Deitel", "Deitel", "Pearson", 2020, 1000);

        Book b2 = new Book("C: Como programar", "Deitel", "Pearson", 2010, 500);

        Book b3 = new Book("Sistemas Operacionais Modernos", "Deitel", "Deitel", "Pearson", 2005);

        Book b4 = new Book("Redes de Computadores", "Deitel", "Pearson", 2010);

        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);
    }
}
